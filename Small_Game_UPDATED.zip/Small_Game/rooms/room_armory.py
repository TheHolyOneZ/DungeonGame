# room_armory.py
room = {
    "description": "An abandoned armory filled with rusty weapons.",
    "connections": ["Hallway"],
    "items": ["Shield"],
    "monster": {
        "name": "Goblin",
        "health": 30
    }
}
