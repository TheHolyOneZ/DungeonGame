# room_hallway.py
room = {
    "description": "A dark, narrow hallway. You hear faint growls in the distance.",
    "connections": ["Entrance", "Armory", "Boss Room"],
    "items": ["Sword"],
    "hidden_details": "The walls have strange carvings, hinting at a hidden passage nearby.",
    "hidden_items": ["Health Potion"]
}
