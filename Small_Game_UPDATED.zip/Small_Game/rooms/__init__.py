# __init__.py
from .room_entrance import room as Entrance
from .room_hallway import room as Hallway
from .room_armory import room as Armory
from .room_boss import room as BossRoom

# Dictionary of all rooms
ROOMS = {
    "Entrance": Entrance,
    "Hallway": Hallway,
    "Armory": Armory,
    "Boss Room": BossRoom,
}
