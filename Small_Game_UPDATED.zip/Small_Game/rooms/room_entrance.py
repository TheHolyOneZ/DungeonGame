# room_entrance.py
room = {
    "description": "You are at the dungeon entrance. A cold breeze sends shivers down your spine.",
    "connections": ["Hallway"],
    "items": ["Torch"]
}
