# room_boss.py
room = {
    "description": "A grand chamber with a towering dragon glaring at you.",
    "connections": ["Hallway"],
    "items": [],
    "monster": {
        "name": "Dragon",
        "health": 100
    }
}
