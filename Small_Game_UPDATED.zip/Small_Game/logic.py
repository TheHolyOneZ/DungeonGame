# logic.py
import random
import json
from rooms import ROOMS
from player import Player
SAVE_FILE = "save_data.json"

def save_game(player):
    """Save the game state to a file."""
    data = {
        "player": player.to_dict(),
        "rooms": ROOMS,
    }
    with open(SAVE_FILE, "w") as f:
        json.dump(data, f)
    print("Game saved!")

def load_game():
    """Load the game state from a file."""
    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
            player = Player.from_dict(data["player"])
            # Reload room states
            for room_name, room_data in data["rooms"].items():
                ROOMS[room_name].update(room_data)
            print("Game loaded successfully!")
            return player
    except FileNotFoundError:
        print("No saved game found.")
        return None

def print_room_description(player):
    """Print the description of the current room."""
    room = ROOMS[player.position]
    print(f"\n{room['description']}")
    if "items" in room and room["items"]:
        print(f"You see the following items: {', '.join(room['items'])}")
    if "monster" in room:
        print(f"Be careful! A {room['monster']['name']} is here.")

def move_player(player, direction):
    """Move the player to a different room."""
    current_room = ROOMS[player.position]
    if direction in current_room["connections"]:
        player.position = direction
        player.score += 10  # Award points for exploration
        print(f"You move to the {direction}. Your score: {player.score}")
        print_room_description(player)
    else:
        print("You can't go that way.")

def pick_up_item(player, item):
    """Allow the player to pick up an item."""
    room = ROOMS[player.position]
    if item in room["items"]:
        player.inventory.append(item)
        room["items"].remove(item)
        player.score += 20  # Award points for picking up items
        print(f"You picked up the {item}. Your score: {player.score}")
    else:
        print("Item not found here.")

def fight_monster(player):
    """Combat sequence with a monster."""
    room = ROOMS[player.position]
    if "monster" in room:
        monster = room["monster"]
        print(f"You encounter a {monster['name']}! Prepare for battle.")
        while monster["health"] > 0 and player.is_alive():
            player_action = input("Choose action: [attack/run]: ").strip().lower()
            if player_action == "attack":
                damage = random.randint(10, 20)
                monster["health"] -= damage
                player.score += 30  # Award points for attacking
                print(f"You dealt {damage} damage to the {monster['name']}. Your score: {player.score}")
                if monster["health"] <= 0:
                    print(f"You defeated the {monster['name']}!")
                    del room["monster"]
                    break
                retaliation = random.randint(5, 15)
                player.health -= retaliation
                print(f"The {monster['name']} retaliates and deals {retaliation} damage. Your health: {player.health}")
            elif player_action == "run":
                print("You flee back to the previous room.")
                break
            else:
                print("Invalid action!")
        if not player.is_alive():
            print("You have been defeated. Game over.")
    else:
        print("No monsters here.")

def look_around(player):
    """Examine the room for hidden details, traps, or treasures."""
    room = ROOMS[player.position]
    print("\nYou carefully look around the room...")
    hidden_details = room.get("hidden_details", None)
    if hidden_details:
        print(hidden_details)
    else:
        print("You don't find anything unusual.")

    # Discover hidden items
    if "hidden_items" in room and room["hidden_items"]:
        print(f"You discovered hidden items: {', '.join(room['hidden_items'])}")
        room["items"].extend(room["hidden_items"])
        room["hidden_items"] = []
        player.score += 50  # Award points for finding hidden treasures
    elif "trap" in room and random.random() < 0.5:
        # Randomly trigger a trap
        trap_damage = random.randint(10, 20)
        player.health -= trap_damage
        player.score -= 20  # Deduct points for falling into a trap
        print(f"A trap triggers! You take {trap_damage} damage. Your health: {player.health}. Your score: {player.score}")
    elif "monster" in room:
        print(f"You notice the {room['monster']['name']} seems vulnerable to fire attacks!")
