# main.py
from player import Player
from logic import (
    print_room_description,
    move_player,
    pick_up_item,
    fight_monster,
    look_around,
    save_game,
    load_game,
)

def game_loop(player):
    """Main game loop."""
    print(f"Welcome back, {player.name}! Your adventure continues...\n")
    print_room_description(player)

    while player.is_alive():
        command = input("\nWhat do you want to do? [move/pick/fight/look/save/load/inventory/quit]: ").strip().lower()
        if command == "move":
            direction = input("Where do you want to go? ").strip()
            move_player(player, direction)
        elif command == "pick":
            item = input("What item do you want to pick up? ").strip()
            pick_up_item(player, item)
        elif command == "fight":
            fight_monster(player)
        elif command == "look":
            look_around(player)
        elif command == "save":
            save_game(player)
        elif command == "load":
            new_player = load_game()
            if new_player:
                player = new_player  # Overwrite current player state
        elif command == "inventory":
            print(f"Inventory: {', '.join(player.inventory)}. Your score: {player.score}")
        elif command == "quit":
            print("Thanks for playing!")
            break
        else:
            print("Invalid command!")

def main():
    """Game entry point."""
    print("Welcome to the Dungeon Adventure Game!")
    print("1. New Game")
    print("2. Load Game")
    choice = input("Choose an option: ").strip()

    if choice == "1":
        player_name = input("Enter your character's name: ").strip()
        player = Player(player_name)
        game_loop(player)
    elif choice == "2":
        player = load_game()
        if player:
            game_loop(player)
        else:
            print("Starting a new game...")
            main()
    else:
        print("Invalid choice!")
        main()

if __name__ == "__main__":
    main()
