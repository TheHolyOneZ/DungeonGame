# player.py
class Player:
    """Represents the player in the game."""
    def __init__(self, name, health=100, inventory=None, position="Entrance", score=0):
        self.name = name
        self.health = health
        self.inventory = inventory if inventory else []
        self.position = position
        self.score = score

    def is_alive(self):
        """Check if the player is alive."""
        return self.health > 0

    def to_dict(self):
        """Convert player state to a dictionary for saving."""
        return {
            "name": self.name,
            "health": self.health,
            "inventory": self.inventory,
            "position": self.position,
            "score": self.score,
        }

    @staticmethod
    def from_dict(data):
        """Create a player from saved data."""
        return Player(
            name=data["name"],
            health=data["health"],
            inventory=data["inventory"],
            position=data["position"],
            score=data["score"],
        )
